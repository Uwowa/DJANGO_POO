from django.contrib import admin
from .models import programmer

# Register your models here.

admin.site.register(programmer)